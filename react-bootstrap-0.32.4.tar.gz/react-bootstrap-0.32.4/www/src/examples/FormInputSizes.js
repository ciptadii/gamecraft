<form>
  <FormGroup bsSize="large">
    <FormControl type="text" placeholder="Large text" />
  </FormGroup>
  <FormGroup>
    <FormControl type="text" placeholder="Normal text" />
  </FormGroup>
  <FormGroup bsSize="small">
    <FormControl type="text" placeholder="Small text" />
  </FormGroup>
</form>;
