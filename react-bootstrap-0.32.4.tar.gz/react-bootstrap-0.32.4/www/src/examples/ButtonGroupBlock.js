<ButtonGroup vertical block>
  <Button>Full width button</Button>
  <Button>Full width button</Button>
</ButtonGroup>;
