<p>
  Badges <Badge>42</Badge>
</p>;
