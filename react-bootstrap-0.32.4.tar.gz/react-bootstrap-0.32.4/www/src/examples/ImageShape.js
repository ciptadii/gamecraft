<Grid>
  <Row>
    <Col xs={6} md={4}>
      <Image src="/thumbnail.png" rounded />
    </Col>
    <Col xs={6} md={4}>
      <Image src="/thumbnail.png" circle />
    </Col>
    <Col xs={6} md={4}>
      <Image src="/thumbnail.png" thumbnail />
    </Col>
  </Row>
</Grid>;
