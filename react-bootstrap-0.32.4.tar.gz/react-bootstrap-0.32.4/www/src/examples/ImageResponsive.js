<Image src="/thumbnail.png" responsive />;
