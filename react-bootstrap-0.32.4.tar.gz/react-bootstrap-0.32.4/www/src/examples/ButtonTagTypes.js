<ButtonToolbar>
  <Button href="#">Link</Button>
  <Button>Button</Button>
</ButtonToolbar>;
