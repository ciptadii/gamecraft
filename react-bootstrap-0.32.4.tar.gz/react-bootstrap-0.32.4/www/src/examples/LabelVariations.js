<div>
  <Label bsStyle="default">Default</Label>{' '}
  <Label bsStyle="primary">Primary</Label>{' '}
  <Label bsStyle="success">Success</Label> <Label bsStyle="info">Info</Label>{' '}
  <Label bsStyle="warning">Warning</Label>{' '}
  <Label bsStyle="danger">Danger</Label>
</div>;
