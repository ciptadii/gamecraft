<div style={{ width: 660, height: 'auto' }}>
  <ResponsiveEmbed a16by9>
    <embed type="image/svg+xml" src="/TheresaKnott_castle.svg" />
  </ResponsiveEmbed>
</div>;
