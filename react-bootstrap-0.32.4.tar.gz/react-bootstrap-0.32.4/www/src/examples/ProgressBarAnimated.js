<ProgressBar active now={45} />;
