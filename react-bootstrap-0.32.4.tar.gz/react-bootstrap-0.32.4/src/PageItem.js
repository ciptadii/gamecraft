import PagerItem from './PagerItem';
import deprecationWarning from './utils/deprecationWarning';

export default deprecationWarning.wrapper(
  PagerItem,
  '`<PageItem>`',
  '`<Pager.Item>`'
);
